document.addEventListener("DOMContentLoaded", function () {
    const formLogin = document.getElementById("form-login");

    formLogin.addEventListener("submit", async function (event) {
        event.preventDefault(); 

        const email = document.getElementById("email-user").value;
        const password = document.getElementById("password-user").value;

        const datos = {
            email: email,
            password: password
        };

        try {
            const respuesta = await fetch("http://localhost:5001/api/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(datos)
            });

            if (!respuesta.ok) {
                console.error("Error en la respuesta del servidor.");
                return;
            }

            const resultado = await respuesta.json();

            if (resultado.message) {

                window.location.href = "dashboard.html";
            } else {
                console.error("Credenciales incorrectas.");
            }
        } catch (error) {
            console.error("Error al intentar iniciar sesión:", error);
        }
    });

    const btnRegister = document.getElementById("btn-register");
    if (btnRegister) {
        btnRegister.addEventListener("click", function () {
            window.location.href = "registro.html";
        });
    }
});
