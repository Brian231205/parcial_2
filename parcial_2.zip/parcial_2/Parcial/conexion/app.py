from flask import Flask, jsonify, request
from flask_cors import CORS
import pymysql
import conexion  

app = Flask(__name__)
CORS(app)


def get_db_connection():
    return pymysql.connect(
        host=conexion.MYSQL_HOST,
        user=conexion.MYSQL_USER,
        password=conexion.MYSQL_PASSWORD,
        db=conexion.MYSQL_DB,
        cursorclass=pymysql.cursors.DictCursor
    )


@app.route('/api/usuarios', methods=['POST'])
def add_user():
    data = request.get_json()
    nombre = data.get('nombre') 
    email = data.get('email')
    password = data.get('password')

    if not nombre or not email or not password:
        return jsonify({'error': 'Todos los campos son obligatorios'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('INSERT INTO usuarios (nombre, email, password) VALUES (%s, %s, %s)', (nombre, email, password))
        conn.commit()
        return jsonify({'message': 'Usuario registrado exitosamente'}), 201
    except pymysql.MySQLError as e:
        return jsonify({'error': str(e)}), 500
    finally:
        cursor.close()
        conn.close()


@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')

    if not email or not password:
        return jsonify({'error': 'Complete los campos'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT password FROM usuarios WHERE email = %s', (email,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()

    if user:
        if user['password'] == password:
            return jsonify({'message': 'Bienvenido'}), 200
        else:
            return jsonify({'error': 'Contraseña incorrecta'}), 401
    return jsonify({'error': 'Usuario no encontrado'}), 401

@app.route('/api/products', methods=['POST'])
def add_product():
    data = request.get_json()
    nombre = data.get('nombre')  
    precio = data.get('precio')  

    if not nombre or not precio:
        return jsonify({'error': 'Todos los campos son obligatorios'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('INSERT INTO productos (nombre, precio) VALUES (%s, %s)', (nombre, precio))
        conn.commit()
        return jsonify({'message': 'Producto registrado'}), 201
    except pymysql.MySQLError as e:
        return jsonify({'error': str(e)}), 500
    finally:
        cursor.close()
        conn.close()


@app.route('/api/products', methods=['GET'])
def get_products():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM productos')
    products = cursor.fetchall()
    cursor.close()
    conn.close()
    
    return jsonify(products), 200

@app.route('/api/products/<int:id>', methods=['DELETE'])
def delete_product(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM productos WHERE id = %s', (id,))
    product = cursor.fetchone()
    
    if not product:
        return jsonify({'error': 'Producto no encontrado'}), 404
    
    cursor.execute('DELETE FROM productos WHERE id = %s', (id,))
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({'message': 'Producto eliminado'}), 200


@app.route('/api/products/<int:id>', methods=['PUT'])
def update_product(id):
    data = request.get_json()
    nombre = data.get('nombre')
    precio = data.get('precio')

    if not nombre or not precio:
        return jsonify({'error': 'Todos los campos son obligatorios'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    
    cursor.execute('SELECT * FROM productos WHERE id = %s', (id,))
    product = cursor.fetchone()
    if not product:
        return jsonify({'error': 'Producto no encontrado'}), 404

    try:
       
        cursor.execute('UPDATE productos SET nombre = %s, precio = %s WHERE id = %s', (nombre, precio, id))
        conn.commit()
        return jsonify({'message': 'Producto actualizado exitosamente'}), 200
    except pymysql.MySQLError as e:
        return jsonify({'error': str(e)}), 500
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    app.run(debug=True, port=5001)
