window.onload = async function () {
    let status = localStorage.getItem("login");
    let currentPage = location.pathname.split("/").pop(); 

    console.log("Estado de login:", status);
    console.log("Página actual:", currentPage);

    if (status !== "ok" && currentPage === "login.html") { 
        location.href = "dashboard.html"; 
    }

    await loadProducts();
};

function showMessage(message, type) {
    const messageDiv = document.createElement("div");
    messageDiv.classList.add("alert", type);
    messageDiv.textContent = message;

    document.body.appendChild(messageDiv);

    setTimeout(function () {
        messageDiv.remove();
    }, 3000);
}

async function loadProducts() {
    const requestOptions = {
        method: "GET",
        redirect: "follow"
    };

    try {
        const response = await fetch("http://127.0.0.1:5001/api/products", requestOptions);
        const products = await response.json();

        const productTable = document.getElementById("productTable");
        
        
        while (productTable.rows.length > 0) {
            productTable.deleteRow(0);
        }

        products.forEach(product => {
            const row = document.createElement("tr");
            row.id = `product-${product.id}`;

            const cellName = document.createElement("td");
            cellName.textContent = product.nombre;

            const cellPrice = document.createElement("td");
            cellPrice.textContent = product.precio;

            const cellActions = document.createElement("td");
            const btnEdit = document.createElement("button");
            btnEdit.classList.add("btn", "btn-warning");
            btnEdit.textContent = "Actualizar";
            btnEdit.onclick = () => editProduct(product.id);

            const btnDelete = document.createElement("button");
            btnDelete.classList.add("btn", "btn-danger");
            btnDelete.textContent = "Eliminar";
            btnDelete.onclick = () => deleteProduct(product.id);

            cellActions.appendChild(btnEdit);
            cellActions.appendChild(btnDelete);

            row.appendChild(cellName);
            row.appendChild(cellPrice);
            row.appendChild(cellActions);

            productTable.appendChild(row);
        });
    } catch (error) {
        console.error("Error al cargar los productos:", error);
    }
}


document.getElementById("formProduct").addEventListener("submit", async function (e) {
    e.preventDefault(); 
    
    let inputName = document.getElementById("nombre").value;
    let inputPrice = document.getElementById("precio").value;

    if (!inputName || !inputPrice) {
        showMessage("Por favor, complete ambos campos.", "alert-danger");
        return false;
    }

    const myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");

    const raw = JSON.stringify({
        "nombre": inputName,
        "precio": inputPrice
    });

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: raw,
        redirect: "follow"
    };

    try {
        const response = await fetch("http://127.0.0.1:5001/api/products", requestOptions);
        const result = await response.json();

        if (result.message === "Producto registrado") {
            showMessage("Producto registrado exitosamente.", "alert-success");
            loadProducts();
            document.getElementById("nombre").value = '';
            document.getElementById("precio").value = '';
        } else {
            showMessage(result.error || "Error al registrar el producto.", "alert-danger");
        }
    } catch (error) {
        console.error("Error al registrar el producto:", error);
    }
});

async function deleteProduct(productId) {
    const requestOptions = {
        method: "DELETE",
        redirect: "follow"
    };

    try {
        const response = await fetch(`http://127.0.0.1:5001/api/products/${productId}`, requestOptions);
        const result = await response.json();

        if (result.message === "Producto eliminado") {
            const productRow = document.getElementById(`product-${productId}`);
            productRow.remove();
            showMessage("Producto eliminado exitosamente.", "alert-success");
        } else {
            showMessage(result.error || "Error al eliminar el producto.", "alert-danger");
        }
    } catch (error) {
        console.error("Error al eliminar el producto:", error);
    }
}

async function editProduct(productId) {
    const productRow = document.getElementById(`product-${productId}`);
    const productName = productRow.cells[0].textContent;
    const productPrice = productRow.cells[1].textContent;

    document.getElementById("nombre").value = productName;
    document.getElementById("precio").value = productPrice;

    const form = document.getElementById("formProduct");
    form.onsubmit = async function (e) {
        e.preventDefault();

        const updatedName = document.getElementById("nombre").value;
        const updatedPrice = document.getElementById("precio").value;

        if (!updatedName || !updatedPrice) {
            showMessage("Por favor, complete ambos campos.", "alert-danger");
            return;
        }

        const myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");

        const raw = JSON.stringify({
            "nombre": updatedName,
            "precio": updatedPrice
        });

        const requestOptions = {
            method: "PUT",
            headers: myHeaders,
            body: raw,
            redirect: "follow"
        };

        try {
            const response = await fetch(`http://127.0.0.1:5001/api/products/${productId}`, requestOptions);
            const result = await response.json();

            if (result.message === "Producto actualizado") {
                showMessage("Producto actualizado exitosamente.", "alert-success");
                loadProducts();
                document.getElementById("nombre").value = '';
                document.getElementById("precio").value = '';
            } else {
                showMessage(result.error || "Error al actualizar el producto.", "alert-danger");
            }
        } catch (error) {
            console.error("Error al actualizar el producto:", error);
        }
    };
}
