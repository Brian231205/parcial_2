document.getElementById('registro-form').addEventListener('submit', function(event) {
    event.preventDefault();
   
    
    
    
    geDiv = document.getElementById('message');
    
    
    messageDiv.textContent = '';

    
    fetch('http://localhost:5001/api/usuarios', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            nombre: nombre,
            email: email,
            password: password
        })
    })
    .then(response => response.json())
    .then(data => {
        messageDiv.textContent = '';

        
        if (data.message) {
            const successMessage = document.createElement('p');
            successMessage.textContent = 'Usuario registrado exitosamente';
            successMessage.classList.add('text-success');
            messageDiv.appendChild(successMessage);
        } else {
            const errorMessage = document.createElement('p');
            errorMessage.textContent = 'Error: ' + data.error;
            errorMessage.classList.add('text-danger');
            messageDiv.appendChild(errorMessage);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        messageDiv.textContent = '';

        const errorMessage = document.createElement('p');
        errorMessage.textContent = 'Hubo un problema con la solicitud';
        errorMessage.classList.add('text-danger');
        messageDiv.appendChild(errorMessage);
    });
});

document.getElementById('btn-login').addEventListener('click', function() {
    window.location.href = 'login.html';
});
